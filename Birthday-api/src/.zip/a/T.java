package a;

import java.util.Scanner;

public class T {

	public static void main(String[] args) {

		if (getIsSpecial() == 1) {
			System.out.println("hhhgh");
		}

	}

	static int getIsSpecial() {
		Scanner ssc = new Scanner(System.in);
		System.out.println("enter V or X");
		int g = ssc.nextInt();
		System.out.println(g);
		return g;

	}
}
