package a;

import java.time.LocalDate;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class BirthdayTask implements Runnable {

	private Set<Person> people;

	private static boolean isRunning = true;

	public BirthdayTask(Set<Person> people) {

		this.people = people;
	}

	@Override
	public void run() {
		while (isRunning) {
			checkDeadlines();
			try {
				TimeUnit.HOURS.sleep(24);
				// Thread.sleep(1000);

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void checkDeadlines() {
		LocalDate month = LocalDate.now();
		try {
			for (Person person : people) {
				if (person.getBirthday().getMonthValue() == month.getMonthValue()
						&& person.getBirthday().getDayOfMonth() == month.getDayOfMonth()) {
					if (person.isSpecial() == true) {
						System.out.println(person.getName() + " is celebrating his birthday today, he was born on "
								+ person.getBirthday());
						Thread.sleep(10000);
						System.out.println("HAPPY BIRTHDAY!!!! ");
					} else {
						System.out.println(person.getName() + " is celebrating his birthday today, he was born on "
								+ person.getBirthday());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void cencelIsRunning() {
		isRunning = false;
	}

	public Set<Person> getPeople() {
		return people;
	}

}
