package test;

public class Run {

	public static void main(String[] args) {

		ReminderSystem reminderSystem = new ReminderSystem();
		reminderSystem.startSystem();
	}

}
